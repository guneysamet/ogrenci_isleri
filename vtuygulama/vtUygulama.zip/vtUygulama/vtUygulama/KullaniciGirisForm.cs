﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vtuygulama
{
    public partial class KullaniciGirisForm : Form
    {
        public KullaniciGirisForm()
        {
            InitializeComponent();
        }

        public static string KullaniciAdi, Kturu;

        public void KullaniciAra()
        {
            try
            {
                Form1.BaglantiAc();
                string Sorgu = "Select * from Kullanicilar where Kadi='"+txtkadi.Text+"' And Sifre='" + txtsifre.Text + "'";
                SqlCommand YukleKomut = new SqlCommand(Sorgu, Form1.Baglanti);
                SqlDataReader dr = YukleKomut.ExecuteReader();
                if (dr.Read())
                {
                    MessageBox.Show("Kullanıcı ADı ve Şifre Doğru \nGiriş Başarılı");
                    KullaniciAdi = txtkadi.Text;
                    Kturu = dr["Kturu"].ToString();

                    Form1.Baglanti.Close();
                    Form1 frmAna = new Form1();
                    frmAna.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Kullanıcı Adı ve Şifre Hatalı \n Tekrar Giriş Yapınız.");
                }
                Form1.Baglanti.Close();
            }
            catch (Exception Hata)
            {

                MessageBox.Show(Hata.Message, "Kullanıcı Girişi Hata Penceresi");

            }
        }

        private void KullaniciGirisForm_Load(object sender, EventArgs e)
        {

        }

        private void btngiris_Click(object sender, EventArgs e)
        {
            KullaniciAra();
        }
    }
}
