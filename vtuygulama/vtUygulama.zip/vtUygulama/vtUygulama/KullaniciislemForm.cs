﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace vtuygulama
{
    public partial class KullaniciislemForm : Form
    {
        public KullaniciislemForm()
        {
            InitializeComponent();
        }
        public void KullaniciListele()
        {
            try
            {
                Form1.BaglantiAc();
                DataSet ds = new DataSet();
                string SorguYönetici = "Select * From Kullanicilar";
                string sorguKullanici = "Select * From Kullanicilar where Kadi='"+lblKadi.Text+"'";

                 if (lblKturu.Text != "Yönetici")
                     SorguYönetici = sorguKullanici;

                SqlDataAdapter da = new SqlDataAdapter(SorguYönetici, Form1.Baglanti);
                da.Fill(ds, "Kullanicilar");
                dataGridView1.DataSource = ds.Tables["Kullanicilar"];
                Form1.Baglanti.Close();

                
            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Kullanici Listele Hata Penceresi");
            }
        }

        public bool AyniKullaniciVar = false;
        public void AyniKullaniciBul()
        {
            try
            {
                Form1.BaglantiAc();
                string Sorgu = "Select * from Kullanicilar where KAdi='" + txtkadi.Text + "'";
                SqlCommand YukleKomut = new SqlCommand(Sorgu, Form1.Baglanti);
                SqlDataReader dr = YukleKomut.ExecuteReader();
                if (dr.Read())
                {
                    AyniKullaniciVar = true;
                }
                else
                {
                    AyniKullaniciVar = false;
                }

                Form1.Baglanti.Close();
            }
            
            catch (Exception Hata)
            {

                MessageBox.Show(Hata.Message, "Aynı Kullanıcı Bul Hata Penceresi");

            }
        }

        public void KullaniciEkle()
        {
            try
            {
                Form1.BaglantiAc();
                string Sorgu = "Insert Into Kullanicilar (kadi,sifre,kturu)Values (@kadi,@sifre,@kturu)";
                SqlCommand EkleKomut = new SqlCommand(Sorgu, Form1.Baglanti);
                EkleKomut.Parameters.AddWithValue("@kadi", txtkadi.Text);
                EkleKomut.Parameters.AddWithValue("@sifre", txtsifre.Text);
                EkleKomut.Parameters.AddWithValue("@kturu", cmbkturu.Text);
                if (AyniKullaniciVar == true)
                    MessageBox.Show("Aynı kullanıcı adı eklenemez!!!");
                else if (EkleKomut.ExecuteNonQuery() == 1)
                    MessageBox.Show("Kullanıcı Eklendi");
                Form1.Baglanti.Close();

            }
            catch (Exception Hata)
            {

                MessageBox.Show(Hata.Message, "Kullanıcı Ekle Hata Penceresi");
            }
        }

        public void SifreDegistir()
        {
            try
            {
                Form1.BaglantiAc();

                string Sorgu = "UPDATE Kullanicilar SET Sifre = @sifre WHERE KKod = @kkod";
                SqlCommand DegistirKomut = new SqlCommand(Sorgu, Form1.Baglanti);
                DegistirKomut.Parameters.AddWithValue("@sifre", txtsifre.Text);
                DegistirKomut.Parameters.AddWithValue("@kkod", txtkkodu.Text);
                if (DegistirKomut.ExecuteNonQuery() == 1)
                    MessageBox.Show(txtkadi.Text + " Adlı Kullanıcının Şifresi Değiştirildi");
                Form1.Baglanti.Close();
            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Şifre Değiştir Hata Penceresi");
            }
        }

        public void KullaniciSil()
        {
            try
            {
                Form1.BaglantiAc();
                string sorgu = "Delete from Kullanicilar where KKod = " + txtkkodu.Text;
                SqlCommand SilKomut = new SqlCommand(sorgu, Form1.Baglanti);
                if (SilKomut.ExecuteNonQuery() == 1)
                    MessageBox.Show(txtkkodu.Text + " Numaralı Kullanıcı Silindi", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Form1.Baglanti.Close();

            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Kullanıcı Sil Hata Penceresi");
            }


        }

        private void btnsil_Click(object sender, EventArgs e)
        {
            if (txtkkodu.Text == "")
                MessageBox.Show("Silinecej kullanıcıyı seçiniz");
            else if (txtkadi.Text == "Admin")
                MessageBox.Show("Bu kayıt silinemez");
            else
            {
                KullaniciSil();
                KullaniciListele();
            }
        }

        private void KullaniciislemForm_Load(object sender, EventArgs e)
        {
            lblKadi.Text = KullaniciGirisForm.KullaniciAdi;
            lblKturu.Text = KullaniciGirisForm.Kturu;
            KullaniciListele();

            if (lblKturu.Text == "Kullanici")
            {
                btnyenikullanici.Enabled = false;
                btnsil.Enabled = false;
                cmbkturu.Enabled = false;
            }
            else
            {

            }
            

        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                txtkkodu.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                txtkadi.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                cmbkturu.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                cmbkturu.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            }
        }

        private void btnyenikullanici_Click(object sender, EventArgs e)
        {
            if (txtkkodu.Text != "")
                MessageBox.Show("Temizle kutusuna basınız.");
            else if (txtkadi.Text == "")
            {
                MessageBox.Show("Kullanıcı adı boş geçilemez");
                txtkadi.Focus();
            }
            else if (txtsifre.Text == "")
            {
                MessageBox.Show("Şifre adı boş geçilemez");
                txtsifre.Focus();
            }
            else if (cmbkturu.Text == "")
            {
                MessageBox.Show("Kullanıcı türü boş geçilemez");
                cmbkturu.Focus();
            }
            else
            {
                KullaniciEkle();
                KullaniciListele();
            }
        }

        private void btntemizle_Click(object sender, EventArgs e)
        {
            txtkkodu.Text = "";

            txtkadi.Text = "";

            txtsifre.Text = "";

            cmbkturu.Text = "Seçiniz";
        }

        private void btnSdegistir_Click(object sender, EventArgs e)
        {
            if (txtkkodu.Text == "")
                MessageBox.Show("Şifresi DEğiştirlecek Kullanıcıyı Seçiniz");
            else if (txtsifre.Text == "")
            {
                MessageBox.Show("Şifre boş geçilemez");
                txtsifre.Focus();
            }
            else
            {
                SifreDegistir();
                KullaniciListele();
            }
        }
    }
}
