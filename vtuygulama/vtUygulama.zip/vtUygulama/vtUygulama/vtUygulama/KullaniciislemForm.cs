﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace vtUygulama
{
    public partial class KullaniciislemForm : Form
    {
        public KullaniciislemForm()
        {
            InitializeComponent();
        }
        public void KullaniciListele()
        {
            try
            {
                Form1.BaglantiAc();
                DataSet ds = new DataSet();
                string SorguYonetici = "Select * from Kullanicilar";
                string SorguKullanici = "Select * from Kullanicilar where Kadi='"+lblKadi.Text+"'";

                if (lblKTuru.Text == "Kullanici")
                    SorguYonetici = SorguKullanici;

            
                SqlDataAdapter da = new SqlDataAdapter(SorguYonetici, Form1.Baglanti);
                da.Fill(ds, "Kullanicilar");
                dataGridView1.DataSource = ds.Tables["Kullanicilar"];
                Form1.Baglanti.Close();
            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Kullanıcı Listele Hata Penceresi");

            }
        }
        public bool AyniKullaniciVar = false;
        public void AyniKullaniciBul()
        {
            try
            {
                Form1.BaglantiAc();
                string Sorgu = "Select * from Kullanicilar where Kadi='" + txtKadi.Text + "'";

                SqlCommand YukleKomut = new SqlCommand(Sorgu, Form1.Baglanti);
                SqlDataReader dr = YukleKomut.ExecuteReader();
                if (dr.Read())
                {
                    AyniKullaniciVar = true;
                }
                else
                {
                    AyniKullaniciVar = false;

                }
                Form1.Baglanti.Close();
            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Aynı Kullanıcı Bul Hata Penceresi");
            }
        }

        public void KullaniciSil()
        {
            try
            {
                Form1.BaglantiAc();
                string Sorgu = "Delete from Kullanicilar where KKod=" + txtKKodu.Text;
                SqlCommand SilKomut = new SqlCommand(Sorgu, Form1.Baglanti);
                if (SilKomut.ExecuteNonQuery() == 1)
                    MessageBox.Show(txtKKodu.Text + "Nolu Kayıt Silindi", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Form1.Baglanti.Close();
            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Kullanıcı Sil Hata Penceresi");
            }
        }






        public void KullaniciEkle()
        {

            try
            {
                Form1.BaglantiAc();
                string Sorgu = ("Insert Into Kullanicilar (Kadi,Sifre,KTuru) Values (@Kadi,@Sifre,@KTuru)");
                SqlCommand EkleKomut = new SqlCommand(Sorgu, Form1.Baglanti);
                EkleKomut.Parameters.AddWithValue("@Kadi", txtKadi.Text);
                EkleKomut.Parameters.AddWithValue("@Sifre", txtSifre.Text);
                EkleKomut.Parameters.AddWithValue("@KTuru", cmbKTuru.Text);

                if (AyniKullaniciVar == true)
                {
                    MessageBox.Show("aynı kullanıcı adı eklenemez!");
                }
                else if (EkleKomut.ExecuteNonQuery() == 1)
                    MessageBox.Show("Kulllanıcı Eklendi", "Kullanıcı  Girişi");
                Form1.Baglanti.Close();

            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Kullanıcı Ekle Hata Penceresi");
            }

        }


        public void SifreDegistir()
        {
            try
            {
                Form1.BaglantiAc();
                string Sorgu = "Update Kullanicilar Set Sifre=@Sifre where KKod=@KKod";
                SqlCommand DegistirKomut = new SqlCommand(Sorgu, Form1.Baglanti);
                
                DegistirKomut.Parameters.AddWithValue("@Sifre", txtSifre.Text);
                DegistirKomut.Parameters.AddWithValue("@KKod", txtKKodu.Text);

                if (DegistirKomut.ExecuteNonQuery() == 1)
                    MessageBox.Show("Sifre Değiştirildi", " Girişi");
                Form1.Baglanti.Close();
            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Sifre Değiştir Hata Penceresi");
            }
        }



        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void KullaniciislemForm_Load(object sender, EventArgs e)
        {
           lblKadi.Text = KullaniciGirisForm.KulllaniciAdi;
           lblKTuru.Text = KullaniciGirisForm.KTuru;
           KullaniciListele();

            if(lblKTuru.Text!="Yönetici")
            {
                btnSil.Enabled = false;
                btnYeni.Enabled = false;

            }
            
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                txtKKodu.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                txtKadi.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                txtSifre.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                cmbKTuru.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            }
        }

        private void lblKTuru_Click(object sender, EventArgs e)
        {

        }

        private void lblKadi_Click(object sender, EventArgs e)
        {

        }

        private void btnYeni_Click(object sender, EventArgs e)
        {
            if (txtKKodu.Text != "")
                MessageBox.Show("Temizle butonuna basın");
            else if (txtKadi.Text == "")
            {
                MessageBox.Show("Kullanıcı adı boş geçilemez");
                txtKadi.Focus();
            }
            else if (txtSifre.Text == "")
            {
                MessageBox.Show("Şifre  boş geçilemez");
                txtSifre.Focus();
            }
            else if (cmbKTuru.Text == "" || cmbKTuru.Text=="Seçiniz")
            {
                MessageBox.Show("Kullanıcı türünü seçiniz boş geçilemez");
                cmbKTuru.Focus();
            }
            else
            {
              AyniKullaniciBul();
              KullaniciEkle();
              KullaniciListele();
            }

        }

        private void btnTemizle_Click(object sender, EventArgs e)
        {
            txtKKodu.Text = "";
            txtKadi.Text = "";
            txtSifre.Text = "";
            cmbKTuru.Text = "Seçiniz";
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (txtKadi.Text == "")
            {
                MessageBox.Show("silinecek kullanıcıyı seçiiniz");
            }
            else if (txtKadi.Text == "admin")
            {
                MessageBox.Show("admin silinemez!!!!");
            }
            else
            {
                KullaniciSil();
                KullaniciListele();
            }
                
        }

        private void btnDegistir_Click(object sender, EventArgs e)
        {
            if (txtKKodu.Text == "")
            {
                MessageBox.Show("sifesi değişecek kullanıcı yaz");
            }
            else if (txtSifre.Text == "")
            {
                MessageBox.Show("sifre boş geçilemez");
                txtSifre.Focus();
            }
            else
            {
                SifreDegistir();
                KullaniciListele();
                
            }

        }
    }
}
