﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace vtUygulama
{
    public partial class KullaniciGirisForm : Form
    {
        public KullaniciGirisForm()
        {
            InitializeComponent();
        }
        public static string KulllaniciAdi, KTuru;
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        public void KullaniciAra()
        {
            try
            {
                Form1.BaglantiAc();
                string Sorgu = "Select * from Kullanicilar where Kadi='"+txtKadi.Text+"' And Sifre='"+txtSifre.Text+"'";
             
                SqlCommand YukleKomut = new SqlCommand(Sorgu, Form1.Baglanti);
                SqlDataReader dr = YukleKomut.ExecuteReader();
               if(dr.Read())
                {
                    MessageBox.Show("Kullanıcı Adı ve Şifre Doğru\nGiriş Başarılı");
                    KulllaniciAdi = txtKadi.Text;
                    KTuru = dr["KTuru"].ToString();
                    Form1.Baglanti.Close();
                    Form1 frmAna = new Form1();
                    frmAna.Show();
                    this.Hide();
                }
               else
                {
                    MessageBox.Show("Kullanıcı Adı ve Şifre Hatalı\nTekrar Giriş Yapınız");

                }
                Form1.Baglanti.Close();
            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Kullanıcı Girişi Hata Penceresi");
            }
        }

        private void KullaniciGirisForm_Load(object sender, EventArgs e)
        {

        }

        private void btnGiris_Click(object sender, EventArgs e)
        {
            KullaniciAra();
        }
    }
}
