﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;//ADO.Net SQL Server Kütüphane Tanımlama

namespace vtUygulama
{
    public partial class KayitDegistirForm : Form
    {
        public KayitDegistirForm()
        {
            InitializeComponent();
        }

        public void VeriDegistir()
        {
            try
            {
                Form1.BaglantiAc();
                string Sorgu = "Select BirimAdi from Birimler";
                SqlCommand DegistirKomut = new SqlCommand(Sorgu, Form1.Baglanti);
                SqlDataReader dr = DegistirKomut.ExecuteReader();
                while (dr.Read())
                {
                    cmbBirim.Items.Add(dr["BirimAdi"]);//Döngü döndüğü kadar veri eklenir String ya da dizilerden veri yazılabilir
                }
                Form1.Baglanti.Close();
            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Birim Değiştir Hata Penceresi");
            }
        }
        private void KayitDegistirForm_Load(object sender, EventArgs e)
        {
            VeriDegistir();

        }
        //DataGridWiev'den alınan verileri değiştirerek kaydeden method.
        public void KayitDegistir()
        {
            try
            {
                Form1.BaglantiAc();
                string Sorgu = "Update Personel Set Ad=@Ad,Soyad=@Soyad,Tcno=@Tcno,Cinsiyet=@Cinsiyet,Birim=@Birim,Dyer=@Dyer,Dtar=@Dtar,Tel=@Tel where Kayitno=@Kayitno";
                SqlCommand DegistirKomut = new SqlCommand(Sorgu, Form1.Baglanti);
                DegistirKomut.Parameters.AddWithValue("@Ad", txtAd.Text);
                DegistirKomut.Parameters.AddWithValue("@Soyad", txtSoyad.Text);
                DegistirKomut.Parameters.AddWithValue("@Tcno", txtTcno.Text);
                if (radErkek.Checked == true)
                    DegistirKomut.Parameters.AddWithValue("Cinsiyet", "Erkek");
                else if (radKadin.Checked == true)
                    DegistirKomut.Parameters.AddWithValue("Cinsiyet", "Kadın");
                DegistirKomut.Parameters.AddWithValue("@Birim", cmbBirim.Text);
                DegistirKomut.Parameters.AddWithValue("@Dyer", cmbDy.Text);
                DegistirKomut.Parameters.AddWithValue("@Dtar", dtDtar.Value);
                DegistirKomut.Parameters.AddWithValue("@Tel", txtTel.Text);
                DegistirKomut.Parameters.AddWithValue("@Kayitno", txtKayitNo.Text);

                if (DegistirKomut.ExecuteNonQuery() == 1)
                    MessageBox.Show("Kayıt Değiştirildi", "Veri Girişi");
                Form1.Baglanti.Close();
            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Kayıt Değiştir Hata Penceresi");
            }
        }

        public bool BoslukKontrol()
        {
            bool bos = false;//Boş alan yok

            lblYildiz1.Visible = false;
            lblYildiz2.Visible = false;
            txtAd.BackColor = Color.White;
            txtSoyad.BackColor = Color.White;
            txtTcno.BackColor = Color.White;
            cmbBirim.BackColor = Color.White;
            cmbDy.BackColor = Color.White;
            txtTel.BackColor = Color.White;

            if (txtTel.Text.Length < 14)//Uzunluğu 11den küçükse
            {
                txtTel.BackColor = Color.Red;
                txtTel.Focus();
                bos = true;//Boş alan var
            }
            if (dtDtar.Value.Date == DateTime.Today.Date)//Bugünün tarihi seçiliyse
            {
                lblYildiz2.Visible = true;
                bos = true;
            }

            if (cmbDy.Text == "" || cmbDy.Text == "Şehir Seçiniz")
            {
                cmbDy.BackColor = Color.Red;
                cmbDy.Focus();
                bos = true;//Boş alan var
            }

            if (cmbBirim.Text == "" || cmbBirim.Text == "Birim Seçiniz")
            {
                cmbBirim.BackColor = Color.Red;
                cmbBirim.Focus();
                bos = true;//Boş alan var
            }

            if (txtTcno.Text.Length < 11)//Uzunluğu 11den küçükse
            {
                txtTcno.BackColor = Color.Red;
                txtTcno.Focus();
                bos = true;//Boş alan var
            }
            if (txtSoyad.Text == "")
            {
                txtSoyad.BackColor = Color.Red;
                txtSoyad.Focus();
                bos = true;//Boş alan var
            }
            if (txtAd.Text == "")
            {
                txtAd.BackColor = Color.Red;
                txtAd.Focus();
                bos = true;//Boş alan var
            }

            return bos;
        }
        private void btnKayitDegistir_Click(object sender, EventArgs e)
        {
            if (BoslukKontrol() == true)//eğer geri dönen değer true ise bi tane boşluk varsa
                MessageBox.Show("Eksik veri girişi", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            else
                KayitDegistir();
       
        }
    }
}
