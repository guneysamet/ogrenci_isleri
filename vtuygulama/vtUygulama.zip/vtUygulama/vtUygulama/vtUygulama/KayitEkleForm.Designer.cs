﻿
namespace vtUygulama
{
    partial class KayitEkleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.txtSoyad = new System.Windows.Forms.TextBox();
            this.txtTcno = new System.Windows.Forms.MaskedTextBox();
            this.radErkek = new System.Windows.Forms.RadioButton();
            this.radKadin = new System.Windows.Forms.RadioButton();
            this.cmbBirim = new System.Windows.Forms.ComboBox();
            this.cmbDy = new System.Windows.Forms.ComboBox();
            this.dtDtar = new System.Windows.Forms.DateTimePicker();
            this.txtTel = new System.Windows.Forms.MaskedTextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblYildiz2 = new System.Windows.Forms.Label();
            this.lblYildiz1 = new System.Windows.Forms.Label();
            this.btnKayitekle = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ad";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Soyad";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(55, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tcno";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(55, 209);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Cinsiyet";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(55, 266);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "Birim";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(55, 323);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "Doğum Yeri";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(55, 380);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(129, 25);
            this.label7.TabIndex = 6;
            this.label7.Text = "Doğum Tarihi";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(55, 437);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(78, 25);
            this.label8.TabIndex = 7;
            this.label8.Text = "Telefon";
            // 
            // txtAd
            // 
            this.txtAd.Location = new System.Drawing.Point(197, 40);
            this.txtAd.Name = "txtAd";
            this.txtAd.Size = new System.Drawing.Size(129, 30);
            this.txtAd.TabIndex = 8;
            // 
            // txtSoyad
            // 
            this.txtSoyad.Location = new System.Drawing.Point(197, 97);
            this.txtSoyad.Name = "txtSoyad";
            this.txtSoyad.Size = new System.Drawing.Size(129, 30);
            this.txtSoyad.TabIndex = 9;
            // 
            // txtTcno
            // 
            this.txtTcno.Location = new System.Drawing.Point(197, 147);
            this.txtTcno.Mask = "00000000000";
            this.txtTcno.Name = "txtTcno";
            this.txtTcno.Size = new System.Drawing.Size(129, 30);
            this.txtTcno.TabIndex = 10;
            this.txtTcno.ValidatingType = typeof(int);
            // 
            // radErkek
            // 
            this.radErkek.AutoSize = true;
            this.radErkek.Location = new System.Drawing.Point(297, 207);
            this.radErkek.Name = "radErkek";
            this.radErkek.Size = new System.Drawing.Size(83, 29);
            this.radErkek.TabIndex = 11;
            this.radErkek.TabStop = true;
            this.radErkek.Text = "Erkek";
            this.radErkek.UseVisualStyleBackColor = true;
            // 
            // radKadin
            // 
            this.radKadin.AutoSize = true;
            this.radKadin.Location = new System.Drawing.Point(197, 207);
            this.radKadin.Name = "radKadin";
            this.radKadin.Size = new System.Drawing.Size(84, 29);
            this.radKadin.TabIndex = 12;
            this.radKadin.TabStop = true;
            this.radKadin.Text = "Kadın";
            this.radKadin.UseVisualStyleBackColor = true;
            // 
            // cmbBirim
            // 
            this.cmbBirim.FormattingEnabled = true;
            this.cmbBirim.Location = new System.Drawing.Point(197, 266);
            this.cmbBirim.Name = "cmbBirim";
            this.cmbBirim.Size = new System.Drawing.Size(154, 33);
            this.cmbBirim.TabIndex = 13;
            this.cmbBirim.Text = "Birim Seçiniz";
            // 
            // cmbDy
            // 
            this.cmbDy.FormattingEnabled = true;
            this.cmbDy.Items.AddRange(new object[] {
            "Ankara",
            "Kastamonu",
            "Bolu",
            "Balıkesir",
            "Bursa",
            "Çanakkale",
            "Zonguldak",
            "Eskişehir",
            "Samsun",
            "Ordu"});
            this.cmbDy.Location = new System.Drawing.Point(196, 323);
            this.cmbDy.Name = "cmbDy";
            this.cmbDy.Size = new System.Drawing.Size(155, 33);
            this.cmbDy.TabIndex = 14;
            this.cmbDy.Text = "Şehir Seçiniz";
            // 
            // dtDtar
            // 
            this.dtDtar.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDtar.Location = new System.Drawing.Point(197, 380);
            this.dtDtar.Name = "dtDtar";
            this.dtDtar.Size = new System.Drawing.Size(154, 30);
            this.dtDtar.TabIndex = 15;
            // 
            // txtTel
            // 
            this.txtTel.Location = new System.Drawing.Point(197, 437);
            this.txtTel.Mask = "(999) 000-0000";
            this.txtTel.Name = "txtTel";
            this.txtTel.Size = new System.Drawing.Size(154, 30);
            this.txtTel.TabIndex = 16;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.Controls.Add(this.lblYildiz2);
            this.panel1.Controls.Add(this.lblYildiz1);
            this.panel1.Controls.Add(this.txtTel);
            this.panel1.Controls.Add(this.dtDtar);
            this.panel1.Controls.Add(this.cmbDy);
            this.panel1.Controls.Add(this.cmbBirim);
            this.panel1.Controls.Add(this.radKadin);
            this.panel1.Controls.Add(this.radErkek);
            this.panel1.Controls.Add(this.txtTcno);
            this.panel1.Controls.Add(this.txtSoyad);
            this.panel1.Controls.Add(this.txtAd);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(32, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(440, 508);
            this.panel1.TabIndex = 17;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // lblYildiz2
            // 
            this.lblYildiz2.AutoSize = true;
            this.lblYildiz2.ForeColor = System.Drawing.Color.DarkRed;
            this.lblYildiz2.Location = new System.Drawing.Point(398, 383);
            this.lblYildiz2.Name = "lblYildiz2";
            this.lblYildiz2.Size = new System.Drawing.Size(20, 25);
            this.lblYildiz2.TabIndex = 18;
            this.lblYildiz2.Text = "*";
            this.lblYildiz2.Visible = false;
            // 
            // lblYildiz1
            // 
            this.lblYildiz1.AutoSize = true;
            this.lblYildiz1.ForeColor = System.Drawing.Color.DarkRed;
            this.lblYildiz1.Location = new System.Drawing.Point(398, 212);
            this.lblYildiz1.Name = "lblYildiz1";
            this.lblYildiz1.Size = new System.Drawing.Size(20, 25);
            this.lblYildiz1.TabIndex = 17;
            this.lblYildiz1.Text = "*";
            this.lblYildiz1.Visible = false;
            // 
            // btnKayitekle
            // 
            this.btnKayitekle.Location = new System.Drawing.Point(32, 551);
            this.btnKayitekle.Name = "btnKayitekle";
            this.btnKayitekle.Size = new System.Drawing.Size(440, 60);
            this.btnKayitekle.TabIndex = 18;
            this.btnKayitekle.Text = "Kayıt Ekle";
            this.btnKayitekle.UseVisualStyleBackColor = true;
            this.btnKayitekle.Click += new System.EventHandler(this.btnKayitekle_Click);
            // 
            // KayitEkleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(504, 627);
            this.Controls.Add(this.btnKayitekle);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "KayitEkleForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "KayitEkleForm";
            this.Load += new System.EventHandler(this.KayitEkleForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtAd;
        private System.Windows.Forms.TextBox txtSoyad;
        private System.Windows.Forms.MaskedTextBox txtTcno;
        private System.Windows.Forms.RadioButton radErkek;
        private System.Windows.Forms.RadioButton radKadin;
        private System.Windows.Forms.ComboBox cmbBirim;
        private System.Windows.Forms.ComboBox cmbDy;
        private System.Windows.Forms.DateTimePicker dtDtar;
        private System.Windows.Forms.MaskedTextBox txtTel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnKayitekle;
        private System.Windows.Forms.Label lblYildiz1;
        private System.Windows.Forms.Label lblYildiz2;
    }
}