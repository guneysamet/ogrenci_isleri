﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;//ADO.Net SQL Server Kütüphane Tanımlama

namespace vtUygulama
{
    public partial class BirimTanimlamaForm : Form
    {
        public BirimTanimlamaForm()
        {
            InitializeComponent();
        }
        public void BirimListele()
        {
            try
            {
                Form1.BaglantiAc();
                DataSet ds = new DataSet();
                string Sorgu = "Select * from Birimler";
                SqlDataAdapter da = new SqlDataAdapter(Sorgu,Form1.Baglanti);
                da.Fill(ds, "Birimler");
                dataGridView1.DataSource = ds.Tables["Birimler"];
                Form1.Baglanti.Close();
            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Birim Listele Hata Penceresi");

            }
        }

        public void BirimEkle()
        {

            try
            {
                Form1.BaglantiAc();
                string Sorgu = ("Insert Into Birimler (BirimAdi) Values (@BirimAdi)");
                SqlCommand EkleKomut = new SqlCommand(Sorgu, Form1.Baglanti);
                EkleKomut.Parameters.AddWithValue("@BirimAdi", txtBirimAdi.Text);
                
                if (EkleKomut.ExecuteNonQuery() == 1)
                    MessageBox.Show("Birim eklendi", "Veri Girişi");
                Form1.Baglanti.Close();

            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Birim Ekle Hata Penceresi");
            }

        }


        private void BirimTanimlamaForm_Load(object sender, EventArgs e)
        {
            BirimListele();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if(dataGridView1.CurrentRow!=null)
            {
                txtBirimKodu.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                txtBirimAdi.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            }
           
        }

        private void btnTemizle_Click(object sender, EventArgs e)
        {
            txtBirimKodu.Text = "";
            txtBirimAdi.Text = "";
            txtBirimAdi.Focus();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            if (txtBirimKodu.Text != "")
                MessageBox.Show("Temizle butonuna basın");
            else if (txtBirimAdi.Text == "")
            {
                MessageBox.Show("Birim adı boş geçilemez");
                txtBirimAdi.Focus();
            }
            else
                BirimEkle();
                BirimListele();

        }

        private void btnSil_Click(object sender, EventArgs e)
        {

        }

        private void btnDegistir_Click(object sender, EventArgs e)
        {

        }
    }
}
