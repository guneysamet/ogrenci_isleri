﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;//ADO.Net SQL Server Kütüphane Tanımlama

namespace vtUygulama
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //SQL Veritabanı Bağlantısı ve Bağlantı Cümleciği
        public static SqlConnection Baglanti = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=vt2B;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        // vt2B ye çift tıkla-> properties-> Connection string'den aldık(Parantez içine çift tırnak açarak aldığımız bağlantıyı içine yapıştırıyoruz)

        //SQL Veritabanı Bağlantısını Kontrollü Şekilde Açan Method
        public static void BaglantiAc()
        {
            try
            {
               // Veritabanı Bağlantısını Kontrollü Olarak Aç
                if (Baglanti.State == ConnectionState.Closed)
                    Baglanti.Open();
            }
            catch (Exception Hata)
            {
                //Sistem Hata Mesajını Yakalamak
                MessageBox.Show(Hata.Message, "Bağlantı Aç Hata Penceresi");
                
            }
        
        }
        //Personel tablosundaki kayırları DataGridViev1 de listeleyen method
        public void KayitListele()
        {
            try
            {
                BaglantiAc();
                DataSet ds = new DataSet();
                string Sorgu = "Select * from Personel";
                SqlDataAdapter da = new SqlDataAdapter(Sorgu,Baglanti);
                da.Fill(ds, "Personel");
                dataGridView1.DataSource = ds.Tables["Personel"];
                Baglanti.Close();
            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Kayıt Listele Hata Penceresi");

            }
        }
        public void VeriYukle()
        {
            try
            {
                Form1.BaglantiAc();
                string Sorgu = "Select BirimAdi from Birimler";
                SqlCommand YukleKomut = new SqlCommand(Sorgu, Form1.Baglanti);
                SqlDataReader dr = YukleKomut.ExecuteReader();
                while (dr.Read())
                {
                    cmbBirim.Items.Add(dr["BirimAdi"]);//Döngü döndüğü kadar veri eklenir String ya da dizilerden veri yazılabilir
                }
                Form1.Baglanti.Close();
            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Birim Yükleme Hata Penceresi");
            }
        }


        //Personel tablosunda seçili alana göre BİREBİR ARAMA yapan metod
        public void KayitAra()
        {
            try
            {
                BaglantiAc();
                DataSet ds = new DataSet();
                string SorguTum = "Select * from Personel";
                string SorguAd = "Select * from Personel where Ad='"+txtAdara.Text+"'";//SINAV SORUSU
                string SorguSoyad = "Select * from Personel where Soyad='" + txtSoyadara.Text + "'";
                string SorguAdSoyad = "Select * from Personel where Ad='" + txtAdara.Text + "' AND Soyad='" + txtSoyadara.Text + "'";
                string SorguBirim = "Select * from Personel where Birim='" + cmbBirim.Text + "'";
                string SorguAdBirim= "Select * from Personel where Ad='" + txtAdara.Text + "' AND Birim='" + cmbBirim.Text + "'";
                string SorguSoyadBirim= "Select * from Personel where Soyad='" + txtSoyadara.Text + "' AND Birim='" + cmbBirim.Text + "'";
                string SorguAdSoyadBirim = "Select * from Personel where Ad='" + txtAdara.Text + "' AND Soyad='" + txtSoyadara.Text + "' AND Birim = '" + cmbBirim.Text+"'";

                if (chkAd.Checked == true && chkSoyad.Checked == true && chkBirimEkle.Checked == true)
                {
                    SorguTum = SorguAdSoyadBirim;
                }
                else if (chkAd.Checked == true && chkSoyad.Checked == true) 
                {
                    SorguTum = SorguAdSoyad;
                }
                else if (chkAd.Checked == true && chkBirimEkle.Checked == true)
                {
                    SorguTum = SorguAdBirim;
                }
                else if (chkSoyad.Checked == true && chkBirimEkle.Checked == true)
                {
                    SorguTum = SorguSoyadBirim;
                }
                else if (chkAd.Checked == true)
                {
                    SorguTum = SorguAd;
                }
                else if (chkSoyad.Checked == true)
                {
                    SorguTum = SorguSoyad;
                }
                else if (chkBirimEkle.Checked == true)
                {
                    SorguTum = SorguBirim;
                }
                
                SqlDataAdapter da = new SqlDataAdapter(SorguTum, Baglanti);
                da.Fill(ds, "Personel");
                dataGridView1.DataSource = ds.Tables["Personel"];
                Baglanti.Close();
            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Kayıt Ara Hata Penceresi");

            }
        }

        //seçilen arama türü ve alana göre yazarken arama yapan metod
        public void HiziliAra()
        {
            try
            {
                BaglantiAc();
                DataSet ds = new DataSet();
                string SorguTum = "Select * from Personel";
                string SorguTcNoileBaslayan = "Select * from personel where TcNo like '"+txtHizliara.Text+"%'";
                string SorguTcNoileBiten = "Select * from personel where TcNo like '%" + txtHizliara.Text + "'"; 
                string SorguTcNoiceren = "Select * from personel where TcNo like '%" + txtHizliara.Text + "%'";

                string SorguDyerileBaslayan = "Select * from personel where Dyer like '" + txtHizliara.Text + "%'";
                string SorguDyerileBiten = "Select * from personel where Dyer like '%" + txtHizliara.Text + "'";
                string SorguDyericeren = "Select * from personel where Dyer like '%" + txtHizliara.Text + "%'";

                string SorguTelileBaslayan = "Select * from personel where tel like '(" + txtHizliara.Text + "%'";
                string SorguTelileBiten = "Select * from personel where tel like '%" + txtHizliara.Text + "'";
                string SorguTeliceren = "Select * from personel where tel like '%" + txtHizliara.Text + "%'";

                string SorguBirimileBaslayan = "Select * from personel where Birim like '" + txtHizliara.Text + "%'";
                string SorguBirimileBiten = "Select * from personel where Birim like '%" + txtHizliara.Text + "'";
                string SorguBirimiceren = "Select * from personel where Birim like '%" + txtHizliara.Text + "%'";

                if (radTcNo.Checked == true)
                {
                    if (cmbaramaTuru.Text == "İle Başlayan")
                    {
                        SorguTum = SorguTcNoileBaslayan;
                    }
                    else if (cmbaramaTuru.Text == "İle Biten")
                    {
                        SorguTum = SorguTcNoileBiten;
                    }
                    else if (cmbaramaTuru.Text == "İçeren")
                    {
                        SorguTum = SorguTcNoiceren;
                    }
                }
                else if (radDyer.Checked == true)
                {
                    if (cmbaramaTuru.Text == "İle Başlayan")
                    {
                        SorguTum = SorguDyerileBaslayan;
                    }
                    else if (cmbaramaTuru.Text == "İle Biten")
                    {
                        SorguTum = SorguDyerileBiten;
                    }
                    else if (cmbaramaTuru.Text == "İçeren")
                    {
                        SorguTum = SorguDyericeren;
                    }
                }

                if (radTel.Checked == true)
                {
                    if (cmbaramaTuru.Text == "İle Başlayan")
                    {
                        SorguTum = SorguTelileBaslayan;
                    }
                    else if (cmbaramaTuru.Text == "İle Biten")
                    {
                        SorguTum = SorguTelileBiten;
                    }
                    else if (cmbaramaTuru.Text == "İçeren")
                    {
                        SorguTum = SorguTeliceren;
                    }
                }

                if (radBirim.Checked == true)
                {
                    if (cmbaramaTuru.Text == "İle Başlayan")
                    {
                        SorguTum = SorguBirimileBaslayan;
                    }
                    else if (cmbaramaTuru.Text == "İle Biten")
                    {
                        SorguTum = SorguBirimileBiten;
                    }
                    else if (cmbaramaTuru.Text == "İçeren")
                    {
                        SorguTum = SorguBirimiceren;
                    }
                }

                SqlDataAdapter da = new SqlDataAdapter(SorguTum, Baglanti);
                da.Fill(ds, "Personel");
                dataGridView1.DataSource = ds.Tables["Personel"];
                Baglanti.Close();
            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Hızlı Ara Hata Penceresi");

            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //MessageBox.Show("Bağlantı Durumu:" + Baglanti.State);
            KayitListele();
            VeriYukle();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            KayitEkleForm frmEkle = new KayitEkleForm();
            frmEkle.ShowDialog();
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            Baglanti.Close();
            KayitListele();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            KayitSilForm frmSil = new KayitSilForm();

            frmSil.txtKayitNo.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            frmSil.txtAd.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            frmSil.txtSoyad.Text= dataGridView1.CurrentRow.Cells[2].Value.ToString();
            frmSil.txtTcNo.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            frmSil.ShowDialog();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            KayitDegistirForm frmDegistir = new KayitDegistirForm();

            frmDegistir.txtKayitNo.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            frmDegistir.txtAd.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            frmDegistir.txtSoyad.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            frmDegistir.txtTcno.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            if (dataGridView1.CurrentRow.Cells[4].Value.ToString() == "Kadın")
                frmDegistir.radKadin.Checked = true;
            else if (dataGridView1.CurrentRow.Cells[4].Value.ToString() == "Erkek")
                frmDegistir.radErkek.Checked = true;
            frmDegistir.cmbBirim.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            frmDegistir.cmbDy.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            frmDegistir.dtDtar.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            frmDegistir.txtTel.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();

            frmDegistir.ShowDialog();
        }

        private void chkAd_CheckedChanged(object sender, EventArgs e)
        {
            if (chkAd.Checked==true)
            {
                txtAdara.Enabled = true;
                txtAdara.Focus();
            }
            else
            {
                txtAdara.Enabled = false;
                txtAdara.Text = "";
            }
        }

        private void txtAdara_TextChanged(object sender, EventArgs e)
        {

        }

        private void chkSoyad_CheckedChanged(object sender, EventArgs e)
        {
            if(chkSoyad.Checked==true)
            {
                txtSoyadara.Enabled = true;
                txtAdara.Focus();
            }
            else
            {
                txtSoyadara.Enabled = false;
                txtAdara.Text = "";
            }
        }

        private void btnAra_Click(object sender, EventArgs e)
        {
            KayitAra();
        }

        private void txtSoyadara_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbBirim_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void chkBirimEkle_CheckedChanged(object sender, EventArgs e)
        {
            if (chkBirimEkle.Checked == true)
            {
                cmbBirim.Enabled = true;
                cmbBirim.Focus();
            }
            else
            {
                cmbBirim.Enabled = false;
                cmbBirim.Text = "";
            }
        }

        private void radTcNo_CheckedChanged(object sender, EventArgs e)
        {
            lblArananAlan.Text = "TC No:";
            txtHizliara.Focus();
            txtHizliara.Text = "";
        }
        //Her yazdığımızda ya da sildiğimizde her tıklandığında çalışır
        private void txtHizliara_TextChanged(object sender, EventArgs e)
        {
            //MessageBox.Show("Tıklandı");
            HiziliAra();
        }

        private void radDyer_CheckedChanged(object sender, EventArgs e)
        {
            lblArananAlan.Text = "Doğum Yeri:";
            txtHizliara.Focus();
            txtHizliara.Text = "";
        }

        private void radTel_CheckedChanged(object sender, EventArgs e)
        {
            lblArananAlan.Text = "Telefon:";
            txtHizliara.Focus();
            txtHizliara.Text = "";
        }

        private void radBirim_CheckedChanged(object sender, EventArgs e)
        {
            lblArananAlan.Text = "Birim:";
            txtHizliara.Focus();
            txtHizliara.Text = "";
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void birimTanımlamaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BirimTanimlamaForm frmBirim = new BirimTanimlamaForm();
            frmBirim.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void kullanıcıİşlemleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KullaniciislemForm frmKullanici = new KullaniciislemForm();
            frmKullanici.ShowDialog();
        }
    }
}
