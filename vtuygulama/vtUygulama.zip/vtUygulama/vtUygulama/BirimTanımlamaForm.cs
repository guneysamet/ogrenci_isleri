﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using vtUygulama;

namespace vtuygulama
{
    public partial class BirimTanımlamaForm : Form
    {
        public BirimTanımlamaForm()
        {
            InitializeComponent();
        }
        public void KayitEkle()
        {
            try
            {
                Form1.BaglantiAc();
                string Sorgu = "Insert Into Birimler (birimAd,birimKod) Values (@birimAd,@birimKod)";
                SqlCommand EkleKomut = new SqlCommand(Sorgu, Form1.Baglanti);
                EkleKomut.Parameters.AddWithValue("@birimAd", txtbirimadi.Text);
                EkleKomut.Parameters.AddWithValue("@birimKod", txtbirimkodu.Text);
                if (EkleKomut.ExecuteNonQuery() == 1)
                    MessageBox.Show("Kayıt Eklendi");
                Form1.Baglanti.Close();

            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Kayıt Ekle Hata Penceresi");
            }

        }
        public void KayitListele()
        {
            try
            {
                Form1.BaglantiAc();
                DataSet ds = new DataSet();
                string Sorgu = "Select * From Birimler";
                SqlDataAdapter da = new SqlDataAdapter(Sorgu, Form1.Baglanti);
                da.Fill(ds, "Birimler");
                dataGridView1.DataSource = ds.Tables["Birimler"];
                Form1.Baglanti.Close();
            }
            catch (Exception Hata)
            {
                MessageBox.Show(Hata.Message, "Birim Listele Hata Penceresi");
            }
        }
    


        private void BirimTanımlamaForm_Load(object sender, EventArgs e)
        {
            KayitListele();
        }

        private void btnekle2_Click(object sender, EventArgs e)
        {
        }

        
    }
}

